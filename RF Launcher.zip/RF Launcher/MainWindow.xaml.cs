﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Security.Cryptography;


namespace RF_Launcher
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    /// 

   public partial class MainWindow : Window
    {
        private INIFile ini = new INIFile(@"System\launcher.ini");
        private const string ChaveCriptografia = "bZp4GY4uhySjAPtpHUXMVyU9TCGKdbMCzJwrjdHXuVFzFpU9z9SGpy8QVUmBTZqh";
        private Socket conexao;
        private readonly string PastaInicializacao = AppDomain.CurrentDomain.BaseDirectory;
        private string _login;
        private string _senha;
        private readonly string _ip;
        private readonly int _porta;
        private readonly string _lang;
        private readonly string _urlCriarConta;
        private readonly string _urlRedefinirSenha;

        public MainWindow()
        {
            InitializeComponent();

            if (this.ini.ReadValue("Geral", "Lembrar") == "true")
            {
                this.salvar_senha.IsChecked = true;
                this.login.Text = this.ini.ReadValue("Conta", "Usuario");
                this.senha.Password = Decriptar(this.ini.ReadValue("Conta", "Senha"));
            }

            try
            {
                string dados = this.ini.ReadValue("Config", "Server");
                dados = Decriptar(dados);
                string[] dadosExtraidos = dados.Split('|');

                this._lang = this.ini.ReadValue("Config", "Lang");
                this._ip = dadosExtraidos[0]; // Ip ou hostname do Servidor de Login
                this._porta =  int.Parse(dadosExtraidos[1]); // Porta usada para conexão.
                this._urlCriarConta = dadosExtraidos[2]; // Url para criar conta.
                this._urlRedefinirSenha = dadosExtraidos[3]; //Url para redefinir senha.
                // this.ini.WriteValue("Config", "Server", Encriptar("127.0.0.1|10001|http://google.com|http://google.com"));
            }
            catch
            {
                MessageBox.Show("Arquivo launcher.ini corrompido, baixe novamente o jogo.", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                // this.ini.WriteValue("Config", "Server", Encriptar("127.0.0.1|10001|http://google.com|http://google.com"));
                Close();
            }

            


        }

        [DllImport("kernel32.dll")]
        private static extern bool CreateProcess(string lpApplicationName, string lpCommandLine, IntPtr lpProcessAttributes, IntPtr lpThreadAttributes, bool bInheritHandles, uint dwCreationFlags, IntPtr lpEnvironment, string lpCurrentDirectory, ref STARTUPINFO lpStartupInfo, out PROCESS_INFORMATION lpProcessInformation);

        private void Fechar(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Entrar(object sender, RoutedEventArgs e)
        {
            this.entrar.Focus();

            this.conexao = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            this._login = this.login.Text;
            this._senha = this.senha.Password;

            if(this._login == "")
            {
                MessageBox.Show("Insira seu login corretamente", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
                

            if (this._senha == "")
            {
                MessageBox.Show("Insira sua senha corretamente", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
                

            if (this.salvar_senha.IsChecked == false)
            {
                this.ini.WriteValue("Geral", "Lembrar", "false");
            }
            else
            {
                this.ini.WriteValue("Geral", "Lembrar", "true");
                this.ini.WriteValue("Conta", "Usuario", this._login);
                this.ini.WriteValue("Conta", "Senha", Encriptar(this._senha));
            }

            try
            {
                this.conexao.Connect(this._ip, this._porta);
            }
            catch
            {
                MessageBox.Show("Falha na conexão [E:1]", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            byte[] stringCarregamentoJogo = new byte[0x37]; // String utilizada pra enviar o comando de inicio do jogo.
            byte[] respostaLogin = new byte[0x40]; // Resposta da requisição de login
            byte[] respostaServidor = new byte[0x40]; // Resposta da requisição de conexão com o servidor de jogo. 
            byte[] buffer = new byte[0x40]; // Buffer de dados utilizado para processamento de informações durante algumas requisições

            // Pacote que solicita as chaves para criptografar o login e senha
            // O pacote pode ser "05 00 15 0C 00" ou "05 00 15 0C FF"
            byte[] pacoteInicial = new byte[] {5,0,0x15,0xC,00};

            try
            {
                this.conexao.Send(pacoteInicial); // Envia o pacote inicial
                this.conexao.Receive(buffer);  // Recebe o pacote de resposta parecido com: 07 00 15 0D 11 22 03 , onde 11 é a chave de soma e 22 é a chave XOR para criptografar a requisição de login 
            }
            catch
            {
                MessageBox.Show("Falha na conexão [E:1]", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);

                return;
            }

            // Pacote de Autenticação
            // 1F 00 15 03 XX XX XX XX XX XX XX XX XX XX XX YY YY YY YY YY YY YY YY YY YY YY 00
            // 1F 00 15 03 Cabeçalho da requisição
            // XX XX XX XX XX XX XX XX XX XX XX  os 12 bytes após o cabeçalho, recebe o login criptografado.
            // YY YY YY YY YY YY YY YY YY YY YY  os 12 Bytes após o login recebe a senha criptografada.
            // 00 Caracter reserva
            byte[] pacoteAutenticacao = new byte[] {0x1f, 0, 0x15, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

            byte[] usuarioASCII = Encoding.ASCII.GetBytes(this._login); // Transforma em bytes o dado de login utilizando a tabela de caracteres ASCII
            byte[] senhaASCII = Encoding.ASCII.GetBytes(this._senha); // Transforma em bytes o dado de senha utilizando a tabela de caracteres ASCII

            int indiceLogin = 0;
            int indiceSenha = 0;
            int indiceInicioCriptografia = 4;

            while (true)
            {
                if (indiceLogin < this._login.Length)
                {
                    // Escreve o login em binario no pacoteAutenticacao a partir do 4º byte
                    pacoteAutenticacao.SetValue(usuarioASCII.GetValue(indiceLogin), (int)(indiceLogin + 4));  

                    indiceLogin++;
                    continue;
                }

                while (true)
                {
                    if (indiceSenha < this._senha.Length)
                    {
                        // Escreve a senha em binario no pacoteAutenticacao a partir do 17º byte
                        pacoteAutenticacao.SetValue(senhaASCII.GetValue(indiceSenha), (int)(indiceSenha + 0x11)); 
                        indiceSenha++;
                        continue;
                    }
                    while (true)
                    {
                        if (indiceInicioCriptografia < 30)
                        {
                            // A variável Buffer neste momento tem a chave resposta contento a chave de soma e XOR para criptografar o pacote de autenticação
                            // Criptografa o pacoteAutenticacao a partir do 4º byte, utilizando a chave de soma + 1 e a chave XOR + 3
                            pacoteAutenticacao.SetValue((byte)(((((byte)pacoteAutenticacao.GetValue(indiceInicioCriptografia)) + ((byte)buffer.GetValue(4))) + 1) ^ (((byte)buffer.GetValue(5)) + 3)), indiceInicioCriptografia); 
                            indiceInicioCriptografia++;
                            continue;
                        }
                        try
                        {
                            // Envia o pacote de autenticação
                            this.conexao.Send(pacoteAutenticacao); 
                            // Recebe o a resposta do servidor, parecida com: 0E 00 15 04 AA XX XX XX XX 01
                            // AA - Status do Login (0x00 OK, 0x06 - login ou senha incorreta)
                            // XX XX XX XX - ID da conta
                            // 01 Conta Premium (01 = Sim, 00 = Não)
                            this.conexao.Receive(respostaLogin); 
                        }
                        catch
                        {
                            MessageBox.Show("Em manutenção [E:3]", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                        if (((byte)respostaLogin.GetValue(4)) != 0)
                        {
                            MessageBox.Show("Login inválido!", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(5)) ^ 0xaf), 0x13);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(6)) ^ 0xe0), 20);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(7)) ^ 0x65), 0x15);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(8)) ^ 110), 0x16);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(5)) ^ 0x3a), 0x29);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(6)) ^ 0x18), 0x2a);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(7)) ^ 0x9c), 0x2b);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(8)) ^ 200), 0x2c);
                        stringCarregamentoJogo.SetValue((((byte)respostaLogin.GetValue(9)) != 1) ? ((byte)0x3a) : ((byte)0x3b), 0x2d);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(11)) ^ 0x18), 0x2e);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(12)) ^ 0x9c), 0x2f);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaLogin.GetValue(13)) ^ 200), 0x30);
                        stringCarregamentoJogo.SetValue((byte)0x3a, 0x27);
                        stringCarregamentoJogo.SetValue((byte)0x4b, 40);

                        // Pacote para listar os servidores do jogo: 08 00 15 05 00 00 00 00
                        byte[] pacoteListaServidores = new byte[] { 8, 0, 0x15, 5, 0, 0, 0, 0 };

                        try
                        {
                            // Enviar o pacote para listar os servidores
                            this.conexao.Send(pacoteListaServidores);

                            // Recebe a lista de servidores
                            // 30 00 15 06 AA 29 00 05 01 06 54 72 69 61 6E 00 01 04 41 73 75 00 01 07 41 6E 6F 6D 69 61 00 01 06 4E 6F 76 75 73 00 01 07 46 61 6C 67 6F 6E 00
                            // AA Status da resposta (0x00 Servidores encontrados, outras respostas, nenhum servidor encontrado)
                            // 29 00 O número de bytes restantes no pacote
                            // 05 O número de servidores no pacote
                            // 01 06 54 72 69 61 6E 00 é o registro exemplo de um servidor
                            // 01 - Habilitado / 00 - Desabilitado
                            // 06 54 72 69 61 6E Nome do servidor
                            // 00 Final 0x00
                            this.conexao.Receive(buffer);
                        }
                        catch
                        {
                            MessageBox.Show("Em manutencao [E:4]", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        // Pacote para conexao com o servidor de jogo
                        // 06 00 15 07 ZZ 00
                        // ZZ é o número do servidor na lista contando a partir de 0
                        byte[] pacoteConectarServidor = new byte[] { 6, 0, 0x15, 7, 0, 0 };

                        try
                        {
                            // Envia um pacote para se conectar no servidor
                            this.conexao.Send(pacoteConectarServidor);

                            // Recebe a resposta da conexao com o servidor
                            // 33 00 15 08 00 59 F9 12 8C 84 6C 09 20 C0 B8 C4 00 15 CD F7 AE 7E FD 2B EC B0 32 8B 0C 00 96 3B 5D 07 30 B7 87 5F 43 BB 35 45 15 25 B3 CD 11 64 4B FA 40
                            // 33 00 15 08 Cabeçalho da resposta
                            // 00 Resultado da operação
                            // 59 F9 12 8C Servidor IP
                            // 84 6C A porta do servidor
                            // A partir do 11º byte começa a chave se sessão, que separamos em 9 conjuntos de DWORDs
                            // 09 20 C0 B8 (0)
                            // C4 00 15 CD (1)
                            // F7 AE 7E FD (2)
                            // 2B EC B0 32 (3)
                            // 8B 0C 00 96 (4)
                            // 3B 5D 07 30 (5)
                            // B7 87 5F 43 (6)
                            // BB 35 45 15 (7)
                            // 25 B3 CD 11 (8)
                            // 64 4B FA 40 (9)
                            this.conexao.Receive(respostaServidor);
                        }
                        catch
                        {
                            MessageBox.Show("Em manutenção [E:5]", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        this.conexao.Close();

                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(11)) ^ 230), 0x17);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(12)) ^ 0x22), 0x18);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(13)) ^ 0xcf), 0x19);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(14)) ^ 0xcf), 0x1a);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(15)) ^ 0x6f), 0x1b);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x10)) ^ 0xde), 0x1c);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x11)) ^ 0xbc), 0x1d);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x12)) ^ 0x5b), 30);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x13)) ^ 0xda), 0x1f);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(20)) ^ 0x5e), 0x20);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x15)) ^ 0xdf), 0x21);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x16)) ^ 0xac), 0x22);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x17)) ^ 0x37), 0x23);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x18)) ^ 0x1b), 0x24);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x19)) ^ 0xcd), 0x25);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(0x1a)) ^ 0xbc), 0x26);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(5)) ^ 0x3a), 0);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(6)) ^ 0x4b), 1);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(7)) ^ 0x9c), 2);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(8)) ^ 0xcb), 3);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(9)) ^ 0xb6), 4);
                        stringCarregamentoJogo.SetValue((byte)(((byte)respostaServidor.GetValue(10)) ^ 0x4f), 5);

                        // Define a lingua do Cliente / Datatable 
                           
                        switch (this._lang)
                        {
                            case "BR": // Portuguese 0xd6
                                stringCarregamentoJogo.SetValue((byte)0xd6, 0x35);
                            break;
                            case "ID": // Indonesian 0xd3
                                stringCarregamentoJogo.SetValue((byte)0xd3, 0x35);
                            break;
                            case "PH": // Philippines 0xd1
                                stringCarregamentoJogo.SetValue((byte)0xd1, 0x35);
                            break;
                            case "RU": // Russian 0xd0
                                stringCarregamentoJogo.SetValue((byte)0xd0, 0x35);
                            break;
                            case "US": // English 0xd4
                                stringCarregamentoJogo.SetValue((byte)0xd4, 0x35);
                            break;
                            default:   // Default US
                                stringCarregamentoJogo.SetValue((byte)0xd4, 0x35);
                            break;
                        }
                        
                        stringCarregamentoJogo.SetValue((byte)50, 0x36);

                        try
                        {

                            File.WriteAllBytes(PastaInicializacao + @"System\DefaultSet.tmp", stringCarregamentoJogo);
                        }
                        catch
                        {
                            MessageBox.Show("Acesso negado na pasta: " + PastaInicializacao, "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        break;
                    }
                    break;
                }
                break;
            }

            

            try
            {
                STARTUPINFO gameStartupInfo = new STARTUPINFO();
                PROCESS_INFORMATION gameProcessInformation = new PROCESS_INFORMATION();

                if (stringCarregamentoJogo.Length < 50)
                {
                    MessageBox.Show("Falha ao iniciar o Jogo.", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    CreateProcess(PastaInicializacao + "RF_Online.bin", null, IntPtr.Zero, IntPtr.Zero, false, 0, IntPtr.Zero, null, ref gameStartupInfo, out gameProcessInformation);
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Arquivo RF_online.bin não encontrado [E:0]", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
            }



        }


        public struct PROCESS_INFORMATION
        {
            public IntPtr hProcess;
            public IntPtr hThread;
            public uint dwProcessId;
            public uint dwThreadId;
        }

        public struct STARTUPINFO
        {
            public uint cb;
            public string lpReserved;
            public string lpDesktop;
            public string lpTitle;
            public uint dwX;
            public uint dwY;
            public uint dwXSize;
            public uint dwYSize;
            public uint dwXCountChars;
            public uint dwYCountChars;
            public uint dwFillAttribute;
            public uint dwFlags;
            public short wShowWindow;
            public short cbReserved2;
            public IntPtr lpReserved2;
            public IntPtr hStdInput;
            public IntPtr hStdOutput;
            public IntPtr hStdError;
        }

        private void MoverJanela(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();

        }

        private void CriarConta(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start(_urlCriarConta);
        }

        private void EsquecerSenha(object sender, MouseButtonEventArgs e)
        {
            System.Diagnostics.Process.Start(_urlRedefinirSenha);
        }

        private void Configuracoes(object sender, RoutedEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(PastaInicializacao + @"rfconfig.exe");
            }
            catch
            {
                MessageBox.Show("Arquivo rfconfig.exe não encontrado [E:0]", "RF Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
        }

        private void BotaoEnter(object sender, KeyEventArgs e)
        {
            
            if (e.Key.Equals(Key.Enter))          
                this.Entrar(null, null);
                
            
        }

        private void SenhaPlaceholder(object sender, RoutedEventArgs e)
        {
            if (this.senha.Password == "")
            {
                this.placeholder_senha.Content = "Insira sua senha";
                this.placeholder_senha.Visibility = System.Windows.Visibility.Visible;
            }
                
            else
            {
                this.placeholder_senha.Content = "";
                this.placeholder_senha.Visibility = System.Windows.Visibility.Hidden; 
            }
                
        }

        private void LoginPlaceholder(object sender, RoutedEventArgs e)
        {
            if (this.login.Text == "")
            {
                this.placeholder_login.Content = "Insira seu login do jogo";
                this.placeholder_login.Visibility = System.Windows.Visibility.Visible;
            }

            else
            {
                this.placeholder_login.Content = "";
                this.placeholder_login.Visibility = System.Windows.Visibility.Hidden;
            }

        }

        private static TripleDESCryptoServiceProvider ObterCriptografia()
        {
            var md5 = new MD5CryptoServiceProvider();
            var key = md5.ComputeHash(Encoding.UTF8.GetBytes(ChaveCriptografia));
            return new TripleDESCryptoServiceProvider() { Key = key, Mode = CipherMode.ECB, Padding = PaddingMode.PKCS7 };
        }

        private static string Encriptar(string TextoPlano)
        {
            var dados = Encoding.UTF8.GetBytes(TextoPlano);
            var tripleDes = ObterCriptografia();
            var transformar = tripleDes.CreateEncryptor();
            var resultadoBytes = transformar.TransformFinalBlock(dados, 0, dados.Length);
            return Convert.ToBase64String(resultadoBytes);
        }

        private static string Decriptar(string TextoCriptografado)
        {
            var data = Convert.FromBase64String(TextoCriptografado);
            var tripleDes = ObterCriptografia();
            var transformar = tripleDes.CreateDecryptor();
            var resultadoBytes = transformar.TransformFinalBlock(data, 0, data.Length);
            return Encoding.UTF8.GetString(resultadoBytes);
        }



    }
}
