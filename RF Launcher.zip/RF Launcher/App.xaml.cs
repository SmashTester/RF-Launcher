﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Windows;

namespace RF_Launcher
{
    /// <summary>
    /// Interação lógica para App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
